#!/bin/bash

workdir=`pwd`
if [ -f wirecell.log ]; then
        echo "The initscript has been executed!" | tee -a wirecell.log
	exit 0 #only run once 
else
        touch wirecell.log
fi

echo "################# Init of job" | tee -a wirecell.log
date | tee -a wirecell.log

echo "larsoft and sbndcode version" | tee -a wirecell.log
echo $LARSOFT_VERSION | tee -a wirecell.log
echo $SBNDCODE_VERSION | tee -a wirecell.log
echo $WIRECELL_VERSION | tee -a wirecell.log

# echo "Tarball extraction" | tee -a wirecell.log
# mkdir WCPwork
# ls | tee -a wirecell.log
# echo "INPUT_TAR_FILE: {$INPUT_TAR_FILE}" | tee -a wirecell.log
# tar -xvf $INPUT_TAR_FILE -C WCPwork | tee -a wirecell.log
echo "INPUT_TAR_DIR_LOCAL_1: {$INPUT_TAR_DIR_LOCAL_1}" | tee -a wirecell.log
ls $INPUT_TAR_DIR_LOCAL_1/ | tee -a wirecell.log 
date | tee -a wirecell.log

# echo "Doing WIRECELL_PATH setup" | tee -a wirecell.log
# ls | tee -a ../wirecell.log 
cd $INPUT_TAR_DIR_LOCAL_1
# setup_job.sh is optional (not always shipped in the dropbox tar)
if [ -f setup_job.sh ]; then
  source setup_job.sh
else
  echo "wirecell_init: setup_job.sh not present — continuing" | tee -a "$workdir/wirecell.log"
fi

cd $workdir
echo "echo \$WIRECELL_PATH" | tee -a wirecell.log
echo $WIRECELL_PATH | tee -a wirecell.log

ls $workdir/ | tee -a wirecell.log 


echo "INPUT_TAR_DIR_LOCAL_1: {$INPUT_TAR_DIR_LOCAL_1}" | tee -a wirecell.log
ls $INPUT_TAR_DIR_LOCAL_1/ | tee -a wirecell.log 



date | tee -a wirecell.log
echo "################# Done!" | tee -a wirecell.log

