rec0f=$(ls | grep rec-0)
mv $rec0f g4-rec-0.h5
