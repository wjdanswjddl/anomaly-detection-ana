#!/bin/bash
#
export WIRECELL_PATH=`pwd`/cfg:$WIRECELL_PATH
echo "WIRECELL_PATH:"
echo $WIRECELL_PATH

export LD_LIBRARY_PATH=`pwd`/lib64:$LD_LIBRARY_PATH
echo "LD_LIBRARY_PATH:"
echo $LD_LIBRARY_PATH
~

